// ============================================================================
// FOG LIFTER  ·  Supabase Edge Function: analyze
// ----------------------------------------------------------------------------
// Holds the Anthropic key server-side so it never reaches the browser.
// Takes { text }, runs the detection prompt, returns { flags }.
//
// DEPLOY NOTES (do these in the Supabase dashboard):
//   1. Edge Functions > Create function, name it exactly:  analyze
//   2. Paste this whole file in.
//   3. Turn OFF "Verify JWT" for this function (it is a public free tool,
//      no login, no user data). Without this the browser would need a token.
//   4. Add a secret named  ANTHROPIC_API_KEY  with your key as the value.
//   5. Deploy.
// ============================================================================

const ANTHROPIC_API_KEY = Deno.env.get("ANTHROPIC_API_KEY");

const CORS = {
  "Access-Control-Allow-Origin": "*", // public tool, no credentials, no user data
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "content-type",
};

// ---- The detection prompt. This is the product. Edit the taxonomy here. ----
const SYSTEM_PROMPT = `You are Fog Lifter. You detect manipulation and fabrication TELLS in a passage of text. You do NOT decide whether claims are true or false. You surface the rhetorical moves the text is making so a reader can see them for themselves.

Use ONLY these tell types (return the id in the "tell" field):
- loaded_language: Word choice doing argumentative work the evidence has not earned.
- vague_unfalsifiable: A claim built so it can never be checked or proven wrong.
- false_urgency: Manufactured time pressure or scarcity meant to stop the reader thinking.
- fear_outrage: Content engineered to spike fear or anger so emotion carries the argument.
- strawman: A weakened or invented version of the other side, set up to knock down.
- anecdote_as_proof: A single story presented as if it settles a general pattern.
- false_binary: Two options framed as the only options when the real space has more.
- unsourced_authority: Appeal to experts, studies, or sources that are never named.
- manufactured_consensus: "Everyone knows," "people are saying," borrowing a crowd not shown to exist.
- deflection: Changing the subject to someone else's fault instead of answering the point.
- decoy_occult: Takes a legitimate, checkable suspicion and reroutes it into a claim built so it can never be tested or disproven, capturing the reader's distrust instead of resolving it. Flag this when real institutional grievance is redirected into an unfalsifiable narrative.

Rules:
- Quote the exact span from the source text that triggers each tell. The span must be a verbatim substring of the input, copied character for character.
- One span carries one tell. If a span does two things, pick the dominant move.
- Do not flag neutral, sourced, or fairly stated content. Restraint matters. If the passage is clean, return an empty array.
- For each flag, write a one-sentence mechanism: what the move is doing to the reader. Plain language, no jargon. Never say whether the underlying claim is true.
- Do not invent spans. If you cannot find the exact text, do not include it.

Respond with ONLY a JSON object, no preamble, no markdown fences:
{"flags":[{"span":"exact text from input","tell":"tell_id","mechanism":"one plain sentence"}]}`;

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "content-type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  if (!ANTHROPIC_API_KEY) {
    return json({ error: "Server missing ANTHROPIC_API_KEY secret", flags: [] }, 500);
  }

  try {
    const { text } = await req.json();
    if (!text || typeof text !== "string" || !text.trim()) {
      return json({ error: "No text provided", flags: [] }, 400);
    }

    const apiRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1500,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: text }],
      }),
    });

    const data = await apiRes.json();

    // If Anthropic returned an error object, surface the real reason up top.
    if (data.type === "error" || data.error) {
      const t = data.error?.type || "unknown";
      const m = data.error?.message || JSON.stringify(data);
      return json({ error: `Anthropic: ${t} — ${m}`, flags: [] }, 502);
    }

    const raw = (data.content || [])
      .filter((b: { type: string }) => b.type === "text")
      .map((b: { text: string }) => b.text)
      .join("")
      .replace(/```json/g, "")
      .replace(/```/g, "")
      .trim();

    let flags = [];
    try {
      const parsed = JSON.parse(raw);
      flags = Array.isArray(parsed.flags) ? parsed.flags : [];
    } catch {
      // Show what the model actually said so we can see why it would not parse.
      return json({ error: "Model did not return clean JSON", raw, flags: [] }, 502);
    }

    return json({ flags }, 200);
  } catch (e) {
    return json({ error: String(e), flags: [] }, 500);
  }
});
